const MAX_REPLY_LENGTH = 30;

// 保持原有text.length上限（含表情、标点）；一个组合表情也不能绕过30上限。
function countReplyEmoji(value) {
  return (String(value || "").match(/(?:\p{Regional_Indicator}{2}|[0-9#*]\uFE0F?\u20E3|\p{Extended_Pictographic}(?:\uFE0F|\p{Emoji_Modifier})?(?:\u200D\p{Extended_Pictographic}(?:\uFE0F|\p{Emoji_Modifier})?)*)/gu) || []).length;
}

function hasMeaningfulReplyText(value) {
  const text = String(value || "").normalize("NFKC").trim();
  if (!text || /^\[skip\]$/i.test(text)) return false;
  // Require at least one letter or number. This rejects punctuation-only and
  // emoji-only outputs while keeping short Chinese, English, and numeric replies.
  return /[\p{L}\p{N}]/u.test(text);
}

function isReplyMetaText(value) {
  const text = String(value || "").normalize("NFKC").replace(/\s+/g, " ").trim();
  if (!text) return false;
  return /\[\s*skip\s*\]/i.test(text) ||
    /(?:my\s+thought\s+process|thought\s+process|chain\s+of\s+thought|thinking\s*过程|思考过程|思路|分析如下|分析：|推理：|reasoning|analysis:|final\s+(?:answer|reply)|最终答案|最终回复|候选(?:回复|答案)|我会选择|ultimately|let['’]s\s+(?:think|see)|作为(?:一个)?(?:ai|人工智能)|as an ai)/i.test(text);
}

// A safety refusal is an instruction to skip the post, never a reply draft.
// Keep this focused on refusal language plus a safety context so ordinary
// comments containing words such as “不能” are unaffected.
function isModelRefusalReply(value) {
  const text = String(value || "").normalize("NFKC").replace(/\s+/g, " ").trim();
  if (!text || /^\[skip\]$/i.test(text)) return false;
  const refusal = /(?:不能|无法|不便|拒绝|不可以|不可|不能够|无法协助|无法提供|不能提供|不能帮助|不予|不支持|can't|cannot|unable|won't|will not|decline|refuse|not able)/i;
  const safety = /(?:色情|淫秽|黄色|露骨|裸体|性内容|违法|违规|有害|危险|仇恨|暴力|谣言|虚假信息|垃圾|不实|spam|misinformation|disinformation|explicit|sexual|illegal|harmful|unsafe|policy|guidelines|safety)/i;
  const refusalOpening = /^(?:抱歉|很抱歉|对不起|不好意思|作为(?:一个)?(?:人工智能|AI)|我是(?:一个)?AI|sorry|i(?:['’]m| am) sorry|as an ai|i cannot|i can't|i am unable|i'm unable)/i;
  return (refusalOpening.test(text) && refusal.test(text)) ||
    (refusal.test(text) && safety.test(text) && text.length >= 10);
}

function isSafeReplyCandidate(value) {
  return !getReplyCandidateIssue(value);
}

function getReplyCandidateIssue(value) {
  const raw = String(value || "").trim();
  const text = raw.normalize("NFKC");
  if (!text) return "empty";
  if (/^\[skip\]$/i.test(text) || /\[\s*skip\s*\]/i.test(text)) return "model_skip";
  if (raw.length > MAX_REPLY_LENGTH || text.length > MAX_REPLY_LENGTH) return "too_long";
  if ((text.match(/[，,]/g) || []).length > 1) return "too_many_commas";
  if (/[。.]$/.test(text)) return "trailing_period";
  if (countReplyEmoji(text) > 1) return "too_many_emoji";
  if (/https?:\/\/|www\.|@[A-Za-z0-9_]+|[#＃][\p{L}\p{N}_]+/u.test(text)) return "unsolicited_contact";
  if (isReplyMetaText(text)) return "model_meta";
  if (isModelRefusalReply(text)) return "refusal";
  if (!hasMeaningfulReplyText(text)) return "punctuation";
  return "";
}
